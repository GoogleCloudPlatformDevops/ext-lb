# dso-gcpfoundation-iac-module-fortigate

This repository is for the **gcpfoundation** application in the **DSO** department.
