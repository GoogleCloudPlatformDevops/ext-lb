#!/bin/sh

PROJECT_ID='my-project-amit1-415215'
SA="network-sa@my-project-amit1-415215.iam.gserviceaccount.com"
TFVARS_FILE_1='health_check.tfvars'



echo "*************** Setting up default project **********************"

echo -e "$PROJECT_ID"

gcloud config set project "$PROJECT_ID"

echo -e "----------------------------------------------------------------------------------------------------------"
echo -e "----------------------------------------------------------------------------------------------------------"
echo -e "\n"

echo "*************** Generating Oauth Access Token *******************"

export MYTOKEN=$(gcloud auth print-access-token --impersonate-service-account=$SA)

echo -e "\n"


terraform init -upgrade
echo -e "----------------------------------------------------------------------------------------------------------"
echo -e "----------------------------------------------------------------------------------------------------------"
echo -e "\n"

: 
echo "********************** Terraform Plan ***************************"

terraform plan \
-var="access_token=$MYTOKEN" \
-var="project_id=$PROJECT_ID" \
-var-file=${TFVARS_FILE_1} 

echo -e "\n"
echo -e "----------------------------------------------------------------------------------------------------------"
echo -e "----------------------------------------------------------------------------------------------------------"
echo -e "\n"


echo "********************** Terraform Apply **************************"
echo -e "\n"
read -p "Your infrastructure is getting changed. Are you Sure ? y or n: " ans
echo -e "Answer: $ans"
if [[ "$ans" == "y" ]]
then
    terraform apply \
    -var="access_token=$MYTOKEN" \
    -var="project_id=$PROJECT_ID" \
    -var-file=${TFVARS_FILE_1} 
    echo -e "------------------------------------------------------------------------------------------------------"
    echo -e "------------------------------------------------------------------------------------------------------"

    echo -e "\n"

else
    echo -e "Answer is 'n', Hence, exiting."
fi