#!/bin/sh
PROJECT_ID='prj-boot-iac-us-1'
SA="id-sa-boot-iac-us-4000@prj-boot-iac-us-1.iam.gserviceaccount.com"
TFVARS_FILE_1='armor.tfvars'
 
gcloud config set project ${PROJECT_ID}
 
export MYTOKEN=$(gcloud auth print-access-token --impersonate-service-account=$SA)
 
terraform init -upgrade
 
echo "********************** Terraform Plan ***************************"
 
terraform plan \
-var="access_token=${MYTOKEN}" \
-var="project_id=${PROJECT_ID}" \
-var-file=${TFVARS_FILE_1}
 
echo -e "\n"
echo -e "----------------------------------------------------------------------------------------------------------"
echo -e "----------------------------------------------------------------------------------------------------------"
echo -e "\n"
 
echo "********************** Terraform Apply **************************"
echo -e "\n"
read -p "Your infrastructure is getting changed. Are you Sure ? y or n: " ans
echo -e "Answer: $ans"
if [ $ans == "y" ]
then
    terraform apply \
   -var="access_token=${MYTOKEN}" \
    -var="project_id=${PROJECT_ID}" \
    -var-file=${TFVARS_FILE_1}
 
    echo -e "------------------------------------------------------------------------------------------------------"
    echo -e "------------------------------------------------------------------------------------------------------"
 
    echo -e "\n"
else
    echo -e "Answer is 'n', Hence, exiting."
fi